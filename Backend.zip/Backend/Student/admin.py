from django.contrib import admin
from .models import TimeTable,ClassroomPortal,Resources,Assignment

admin.site.register(TimeTable)
admin.site.register(ClassroomPortal)
admin.site.register(Resources)
admin.site.register(Assignment)
