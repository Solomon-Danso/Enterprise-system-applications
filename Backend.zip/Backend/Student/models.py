from django.db import models
from django.contrib.auth.models import User


class Assignment(models.Model):
    image = models.ImageField(blank=True,upload_to="assignment/images")
    audio = models.FileField(blank=True,upload_to="assignment/audio")
    video = models.FileField(blank=True,upload_to="assignment/video")
    file = models.FileField(blank=True,upload_to="assignment/Files")
    text = models.TextField(blank=True)
    sender = models.ForeignKey(User,on_delete=models.CASCADE)
    date = models.DateTimeField(auto_now_add=True)
    class Meta:
        verbose_name_plural = "Assignments"
    def __str__(self):
        return self.text

class Resources(models.Model):
    links = models.CharField(max_length=10000, blank=True)
    image = models.ImageField(blank=True,upload_to="assignment/images")
    audio = models.FileField(blank=True,upload_to="assignment/audio")
    video = models.FileField(blank=True,upload_to="assignment/video")
    file = models.FileField(blank=True,upload_to="assignment/Files")
    sender = models.ForeignKey(User,on_delete=models.CASCADE)
    date = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "Resources"
    def __str__(self):
        return self.links

class ClassroomPortal(models.Model):
    image = models.ImageField(blank=True,upload_to="student/images")
    audio = models.FileField(blank=True,upload_to="student/audio")
    video = models.FileField(blank=True,upload_to="student/video")
    file = models.FileField(blank=True,upload_to="student/Files")
    text = models.TextField(blank=True)
    sender = models.ForeignKey(User,on_delete=models.CASCADE)
    date = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "Classroom Portal"
    def __str__(self):
        return self.text
    
class TimeTable(models.Model):
    timetable = models.FileField(upload_to="student/timetable")
    date = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "Time Table"
    def __str__(self):
        return self.date

