from django.contrib import admin
from django.urls import path,include
from django.conf.urls.static import static
from django.conf import settings 
from Administration import url as AdminUrl
from Public import url as PublicUrl


urlpatterns = [
    path('hydotschool/', admin.site.urls),
    path("",include(PublicUrl)),
    path("",include(AdminUrl)),




]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

