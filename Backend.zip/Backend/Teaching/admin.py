from django.contrib import admin
from .models import LessonNotes, TeachersPortal,Teaching_and_learningMaterialPicture,Teaching_and_learningMaterialVideo,Teaching_and_learningMaterialAudio,AcademicResult,StudentAttendance

admin.site.register(LessonNotes)
admin.site.register(TeachersPortal)
admin.site.register(Teaching_and_learningMaterialPicture)
admin.site.register(Teaching_and_learningMaterialVideo)
admin.site.register(Teaching_and_learningMaterialAudio)
admin.site.register(StudentAttendance)
admin.site.register(AcademicResult)

