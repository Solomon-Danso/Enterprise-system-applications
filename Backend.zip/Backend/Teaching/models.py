from django.db import models
from django.contrib.auth.models import User


class LessonNotes(models.Model):
    subject = models.CharField(max_length=200)
    learning_indicator=models.CharField(max_length=200)
    performance_indicator = models.CharField(max_length=200)
    week_ending = models.DateField()
    reference = models.CharField(max_length=200)
    teaching_resources = models.CharField(max_length=200)
    date = models.DateTimeField(auto_now_add=True)

    monday = models.CharField(default="Monday", editable=False,max_length=100)
    monday_starter = models.TextField(blank=True)
    monday_main = models.TextField(blank=True)
    monday_reflection = models.TextField(blank=True)

    Tuesday = models.CharField(default="Tuesday", editable=False,max_length=100)
    Tuesday_starter = models.TextField(blank=True)
    Tuesday_main = models.TextField(blank=True)
    Tuesday_reflection = models.TextField(blank=True)

    Wednesday = models.CharField(default="Wednesday", editable=False,max_length=100)
    Wednesday_starter = models.TextField(blank=True)
    Wednesday_main = models.TextField(blank=True)
    Wednesday_reflection = models.TextField(blank=True)

    Thursday = models.CharField(default="Thursday", editable=False,max_length=100)
    Thursday_starter = models.TextField(blank=True)
    Thursday_main = models.TextField(blank=True)
    Thursday_reflection = models.TextField(blank=True)

    Friday = models.CharField(default="Friday", editable=False,max_length=100)
    Friday_starter = models.TextField(blank=True)
    Friday_main = models.TextField(blank=True)
    Friday_reflection = models.TextField(blank=True)
    class Meta:
        verbose_name_plural = "Lesson Notes"
    def __str__(self):
        return self.subject +" "+str(self.week_ending)

class TeachersPortal(models.Model):
    sender = models.ForeignKey(User,on_delete=models.CASCADE)
    message = models.TextField()
    message_time = models.DateTimeField(auto_now_add=True)
    class Meta:
        verbose_name_plural = "Teaching_Staff_Portal"
    def __str__(self):
        return self.message

class Teaching_and_learningMaterialPicture(models.Model):
    Pictures = models.FileField(upload_to="TLMS/PICS")
    name = models.CharField(max_length=200)
    class Meta:
        verbose_name_plural = "Teaching and Learning Material Pictures"
    def __str__(self):
        return self.name

class Teaching_and_learningMaterialVideo(models.Model):
    Videos = models.FileField(upload_to="TLMS/Video")
    name = models.CharField(max_length=200)
    class Meta:
        verbose_name_plural = "Teaching and Learning Material Pictures"
    def __str__(self):
        return self.name

class Teaching_and_learningMaterialAudio(models.Model):
    Audio = models.FileField(upload_to="TLMS/Audio")
    name = models.CharField(max_length=200)
    class Meta:
        verbose_name_plural = "Teaching and Learning Material Pictures"
    def __str__(self):
        return self.name

class AcademicResult(models.Model):
    student = models.CharField(max_length=200)
   
    subject1 = models.CharField(max_length=200)
    subject1_class_score = models.FloatField(blank=True)
    subject1_exams_score = models.FloatField(blank=True)
    subject1_total_score = models.FloatField(blank=True)
   
    subject2 = models.CharField(max_length=200)
    subject2_class_score = models.FloatField(blank=True)
    subject2_exams_score = models.FloatField(blank=True)
    subject2_total_score = models.FloatField(blank=True)
   
    subject3 = models.CharField(max_length=200)
    subject3_class_score = models.FloatField(blank=True)
    subject3_exams_score = models.FloatField(blank=True)
    subject3_total_score = models.FloatField(blank=True)
   
    subject4 = models.CharField(max_length=200)
    subject4_class_score = models.FloatField(blank=True)
    subject4_exams_score = models.FloatField(blank=True)
    subject4_total_score = models.FloatField(blank=True)

    subject5 = models.CharField(max_length=200)
    subject5_class_score = models.FloatField(blank=True)
    subject5_exams_score = models.FloatField(blank=True)
    subject5_total_score = models.FloatField(blank=True)

    subject6 = models.CharField(max_length=200)
    subject6_class_score = models.FloatField(blank=True)
    subject6_exams_score = models.FloatField(blank=True)
    subject6_total_score = models.FloatField(blank=True)

    subject7 = models.CharField(max_length=200)
    subject7_class_score = models.FloatField(blank=True)
    subject7_exams_score = models.FloatField(blank=True)
    subject7_total_score = models.FloatField(blank=True)

    subject8 = models.CharField(max_length=200)
    subject8_class_score = models.FloatField(blank=True)
    subject8_exams_score = models.FloatField(blank=True)
    subject8_total_score = models.FloatField(blank=True)

    subject9 = models.CharField(max_length=200)
    subject9_class_score = models.FloatField(blank=True)
    subject9_exams_score = models.FloatField(blank=True)
    subject9_total_score = models.FloatField(blank=True)

    subject10 = models.CharField(max_length=200)
    subject10_class_score = models.FloatField(blank=True)
    subject10_exams_score = models.FloatField(blank=True)
    subject10_total_score = models.FloatField(blank=True)
    
    class Meta:
        verbose_name_plural = "Academic Records"
    def __str__(self):
        return self.student





class StudentAttendance(models.Model):
    student_name = models.CharField(max_length=1000)
    week_1_mon = models.BooleanField(default=False)
    week_1_tue = models.BooleanField(default=False)
    week_1_wed = models.BooleanField(default=False)
    week_1_thur = models.BooleanField(default=False)
    week_1_fri = models.BooleanField(default=False)

    week_2_mon = models.BooleanField(default=False)
    week_2_tue = models.BooleanField(default=False)
    week_2_wed = models.BooleanField(default=False)
    week_2_thur = models.BooleanField(default=False)
    week_2_fri = models.BooleanField(default=False)

    week_3_mon = models.BooleanField(default=False)
    week_3_tue = models.BooleanField(default=False)
    week_3_wed = models.BooleanField(default=False)
    week_3_thur = models.BooleanField(default=False)
    week_3_fri = models.BooleanField(default=False)

    week_4_mon = models.BooleanField(default=False)
    week_4_tue = models.BooleanField(default=False)
    week_4_wed = models.BooleanField(default=False)
    week_4_thur = models.BooleanField(default=False)
    week_4_fri = models.BooleanField(default=False)

    week_5_mon = models.BooleanField(default=False)
    week_5_tue = models.BooleanField(default=False)
    week_5_wed = models.BooleanField(default=False)
    week_5_thur = models.BooleanField(default=False)
    week_5_fri = models.BooleanField(default=False)

    week_6_mon = models.BooleanField(default=False)
    week_6_tue = models.BooleanField(default=False)
    week_6_wed = models.BooleanField(default=False)
    week_6_thur = models.BooleanField(default=False)
    week_6_fri = models.BooleanField(default=False)

    week_7_mon = models.BooleanField(default=False)
    week_7_tue = models.BooleanField(default=False)
    week_7_wed = models.BooleanField(default=False)
    week_7_thur = models.BooleanField(default=False)
    week_7_fri = models.BooleanField(default=False)

    week_8_mon = models.BooleanField(default=False)
    week_8_tue = models.BooleanField(default=False)
    week_8_wed = models.BooleanField(default=False)
    week_8_thur = models.BooleanField(default=False)
    week_8_fri = models.BooleanField(default=False)

    week_9_mon = models.BooleanField(default=False)
    week_9_tue = models.BooleanField(default=False)
    week_9_wed = models.BooleanField(default=False)
    week_9_thur = models.BooleanField(default=False)
    week_9_fri = models.BooleanField(default=False)

    week_10_mon = models.BooleanField(default=False)
    week_10_tue = models.BooleanField(default=False)
    week_10_wed = models.BooleanField(default=False)
    week_10_thur = models.BooleanField(default=False)
    week_10_fri = models.BooleanField(default=False)

    week_11_mon = models.BooleanField(default=False)
    week_11_tue = models.BooleanField(default=False)
    week_11_wed = models.BooleanField(default=False)
    week_11_thur = models.BooleanField(default=False)
    week_11_fri = models.BooleanField(default=False)

    week_12_mon = models.BooleanField(default=False)
    week_12_tue = models.BooleanField(default=False)
    week_12_wed = models.BooleanField(default=False)
    week_12_thur = models.BooleanField(default=False)
    week_12_fri = models.BooleanField(default=False)

    week_13_mon = models.BooleanField(default=False)
    week_13_tue = models.BooleanField(default=False)
    week_13_wed = models.BooleanField(default=False)
    week_13_thur = models.BooleanField(default=False)
    week_13_fri = models.BooleanField(default=False)

    week_14_mon = models.BooleanField(default=False)
    week_14_tue = models.BooleanField(default=False)
    week_14_wed = models.BooleanField(default=False)
    week_14_thur = models.BooleanField(default=False)
    week_14_fri = models.BooleanField(default=False)

    week_15_mon = models.BooleanField(default=False)
    week_15_tue = models.BooleanField(default=False)
    week_15_wed = models.BooleanField(default=False)
    week_15_thur = models.BooleanField(default=False)
    week_15_fri = models.BooleanField(default=False)

    week_16_mon = models.BooleanField(default=False)
    week_16_tue = models.BooleanField(default=False)
    week_16_wed = models.BooleanField(default=False)
    week_16_thur = models.BooleanField(default=False)
    week_16_fri = models.BooleanField(default=False)

    week_17_mon = models.BooleanField(default=False)
    week_17_tue = models.BooleanField(default=False)
    week_17_wed = models.BooleanField(default=False)
    week_17_thur = models.BooleanField(default=False)
    week_17_fri = models.BooleanField(default=False)

    week_18_mon = models.BooleanField(default=False)
    week_18_tue = models.BooleanField(default=False)
    week_18_wed = models.BooleanField(default=False)
    week_18_thur = models.BooleanField(default=False)
    week_18_fri = models.BooleanField(default=False)

    week_19_mon = models.BooleanField(default=False)
    week_19_tue = models.BooleanField(default=False)
    week_19_wed = models.BooleanField(default=False)
    week_19_thur = models.BooleanField(default=False)
    week_19_fri = models.BooleanField(default=False)

    week_20_mon = models.BooleanField(default=False)
    week_20_tue = models.BooleanField(default=False)
    week_20_wed = models.BooleanField(default=False)
    week_20_thur = models.BooleanField(default=False)
    week_20_fri = models.BooleanField(default=False)
    class Meta:
        verbose_name_plural = "Attendance"
    def __str__(self):
        return self.student_name

