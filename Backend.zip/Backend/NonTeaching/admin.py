from django.contrib import admin
from .models import Security_Portal,FeedingFee,Kitchen,Non_Teaching_Portal

admin.site.register(Security_Portal)
admin.site.register(FeedingFee)
admin.site.register(Kitchen)
admin.site.register(Non_Teaching_Portal)

