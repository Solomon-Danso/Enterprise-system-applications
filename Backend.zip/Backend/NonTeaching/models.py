from django.db import models
from django.contrib.auth.models import User

class Non_Teaching_Portal(models.Model):
    sender = models.ForeignKey(User,on_delete=models.CASCADE)
    message = models.TextField()
    message_time = models.DateTimeField(auto_now_add=True)
    class Meta:
        verbose_name_plural = "Non_Teaching_Staff_Portal"
    def __str__(self):
        return self.message

class Kitchen(models.Model):
    item_name = models.CharField(max_length=1000)
    quantity = models.FloatField()
    price = models.FloatField()
    total_stock = models.FloatField()

    class Meta:
        verbose_name_plural = "Kitchen"
    def __str__(self):
        return self.item_name

class FeedingFee(models.Model):
    student_name = models.CharField(max_length=200)
    week_1_mon = models.FloatField()
    week_1_tue = models.FloatField()
    week_1_wed = models.FloatField()
    week_1_thur = models.FloatField()
    week_1_fri = models.FloatField()

    week_2_mon = models.FloatField()
    week_2_tue = models.FloatField()
    week_2_wed = models.FloatField()
    week_2_thur = models.FloatField()
    week_2_fri = models.FloatField()

    week_3_mon = models.FloatField()
    week_3_tue = models.FloatField()
    week_3_wed = models.FloatField()
    week_3_thur = models.FloatField()
    week_3_fri = models.FloatField()

    week_4_mon = models.FloatField()
    week_4_tue = models.FloatField()
    week_4_wed = models.FloatField()
    week_4_thur = models.FloatField()
    week_4_fri = models.FloatField()

    week_5_mon = models.FloatField()
    week_5_tue = models.FloatField()
    week_5_wed = models.FloatField()
    week_5_thur = models.FloatField()
    week_5_fri = models.FloatField()

    week_6_mon = models.FloatField()
    week_6_tue = models.FloatField()
    week_6_wed = models.FloatField()
    week_6_thur = models.FloatField()
    week_6_fri = models.FloatField()

    week_7_mon = models.FloatField()
    week_7_tue = models.FloatField()
    week_7_wed = models.FloatField()
    week_7_thur = models.FloatField()
    week_7_fri = models.FloatField()

    week_8_mon = models.FloatField()
    week_8_tue = models.FloatField()
    week_8_wed = models.FloatField()
    week_8_thur = models.FloatField()
    week_8_fri = models.FloatField()

    week_9_mon = models.FloatField()
    week_9_tue = models.FloatField()
    week_9_wed = models.FloatField()
    week_9_thur = models.FloatField()
    week_9_fri = models.FloatField()

    week_10_mon = models.FloatField()
    week_10_tue = models.FloatField()
    week_10_wed = models.FloatField()
    week_10_thur = models.FloatField()
    week_10_fri = models.FloatField()

    week_11_mon = models.FloatField()
    week_11_tue = models.FloatField()
    week_11_wed = models.FloatField()
    week_11_thur = models.FloatField()
    week_11_fri = models.FloatField()

    week_12_mon = models.FloatField()
    week_12_tue = models.FloatField()
    week_12_wed = models.FloatField()
    week_12_thur = models.FloatField()
    week_12_fri = models.FloatField()

    week_13_mon = models.FloatField()
    week_13_tue = models.FloatField()
    week_13_wed = models.FloatField()
    week_13_thur = models.FloatField()
    week_13_fri = models.FloatField()

    week_14_mon = models.FloatField()
    week_14_tue = models.FloatField()
    week_14_wed = models.FloatField()
    week_14_thur = models.FloatField()
    week_14_fri = models.FloatField()

    week_15_mon = models.FloatField()
    week_15_tue = models.FloatField()
    week_15_wed = models.FloatField()
    week_15_thur = models.FloatField()
    week_15_fri = models.FloatField()

    week_16_mon = models.FloatField()
    week_16_tue = models.FloatField()
    week_16_wed = models.FloatField()
    week_16_thur = models.FloatField()
    week_16_fri = models.FloatField()

    week_17_mon = models.FloatField()
    week_17_tue = models.FloatField()
    week_17_wed = models.FloatField()
    week_17_thur = models.FloatField()
    week_17_fri = models.FloatField()

    week_18_mon = models.FloatField()
    week_18_tue = models.FloatField()
    week_18_wed = models.FloatField()
    week_18_thur = models.FloatField()
    week_18_fri = models.FloatField()

    week_19_mon = models.FloatField()
    week_19_tue = models.FloatField()
    week_19_wed = models.FloatField()
    week_19_thur = models.FloatField()
    week_19_fri = models.FloatField()

    week_20_mon = models.FloatField()
    week_20_tue = models.FloatField()
    week_20_wed = models.FloatField()
    week_20_thur = models.FloatField()
    week_20_fri = models.FloatField()
    class Meta:
        verbose_name_plural = "Feeding Fee"
    def __str__(self):
        return self.student_name

class Security_Portal(models.Model):
    sender = models.ForeignKey(User,on_delete=models.CASCADE)
    message = models.TextField()
    message_time = models.DateTimeField(auto_now_add=True)
    class Meta:
        verbose_name_plural = "Security_Portal"
    def __str__(self):
        return self.message
    
