from django.contrib import admin
from .models import TermFees,Stage,Subject,MaritalStatus,Teachers,NonTeachers,AdmitTeachers,AdmitStudent,Account_Salary_Teaching,Account_Salary_NonTeaching,SuperVision

admin.site.register(Stage)
admin.site.register(Subject)
admin.site.register(MaritalStatus)
admin.site.register(Teachers)
admin.site.register(TermFees)
admin.site.register(NonTeachers)
admin.site.register(SuperVision)
admin.site.register(AdmitStudent)
admin.site.register(AdmitTeachers)
admin.site.register(Account_Salary_Teaching)
admin.site.register(Account_Salary_NonTeaching)



