from rest_framework import serializers
from .models import TermFees,Stage,Subject,MaritalStatus,Teachers,NonTeachers,AdmitTeachers,AdmitStudent,Account_Salary_Teaching,Account_Salary_NonTeaching,SuperVision

class TermFeesSerializer(serializers.ModelSerializer):
    class Meta:
        model= TermFees
        fields = "__all__"

class StageSerializer(serializers.ModelSerializer):
    class Meta:
        model= Stage
        fields = "__all__"

class SubjectSerializer(serializers.ModelSerializer):
    class Meta:
        model= Subject
        fields = "__all__"

class MaritalStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model= MaritalStatus
        fields = "__all__"

class TeachersSerializer(serializers.ModelSerializer):
    class Meta:
        model= Teachers
        fields = "__all__"

class NonTeachersSerializer(serializers.ModelSerializer):
    class Meta:
        model= NonTeachers
        fields = "__all__"

class AdmitTeachersSerializer(serializers.ModelSerializer):
    class Meta:
        model= AdmitTeachers
        fields = "__all__"

class AdmitStudentSerializer(serializers.ModelSerializer):
    class Meta:
        model= AdmitStudent
        fields = "__all__"

class Account_Salary_TeachingSerializer(serializers.ModelSerializer):
    class Meta:
        model= Account_Salary_Teaching
        fields = "__all__"

class Account_Salary_NonTeachingSerializer(serializers.ModelSerializer):
    class Meta:
        model= Account_Salary_NonTeaching
        fields = "__all__"
class SuperVisionSerializer(serializers.ModelSerializer):
    class Meta:
        model= SuperVision
        fields = "__all__"

