from django.db import models



class Stage(models.Model):
    class_name = models.CharField(max_length=300)
    def __str__(self):
        return self.class_name
    class Meta:
        verbose_name_plural = "Stage"

        
class Subject(models.Model):
    subject = models.CharField(max_length=300)
    def __str__(self):
        return self.subject
    class Meta:
        verbose_name_plural = "Subject"


class MaritalStatus(models.Model):
    status = models.CharField(max_length=100)
    def __str__(self):
        return self.status
    class Meta:
        verbose_name_plural = "Marital Status"


class Teachers(models.Model):
    name = models.CharField(max_length=300)
    def __str__(self):
        return self.name
    class Meta:
        verbose_name_plural = "Teachers"

class TermFees(models.Model):
    term_fees = models.FloatField(null=True)
    def __str__(self):
        self.term_fees = str(self.term_fees)
        return self.term_fees
    class Meta:
        verbose_name_plural = "Term Fees"



class NonTeachers(models.Model):
    name = models.CharField(max_length=300)
    def __str__(self):
        return self.name
    class Meta:
        verbose_name_plural = "Non Teachers"


class AdmitTeachers(models.Model):
    picture = models.ImageField(upload_to="Teachers_Pictures")
    fullname = models.CharField(max_length=300)
    age = models.CharField(max_length=10)
    hometown = models.TextField()
    marital_status = models.ForeignKey(MaritalStatus, on_delete=models.CASCADE)
    education = models.TextField()
    working_experience = models.TextField()
    location = models.TextField()
    contact = models.CharField(max_length=100)
    social_security = models.CharField(max_length=200)
    tax = models.CharField(max_length=200)
    identification = models.CharField(max_length=100,blank=True)
    class_to_handle = models.ForeignKey(Stage, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject,on_delete=models.CASCADE)
    emergency_contact_name = models.CharField(max_length=200)
    emergency_contact = models.CharField(max_length=200)
    def _str__(self):
        return self.fullname
    class Meta:
        verbose_name_plural = "Admit Teachers"



class AdmitStudent(models.Model):
    picture = models.ImageField(upload_to="Student_Pictures")
    fullname = models.CharField(max_length=300)
    age = models.CharField(max_length=10)
    hometown = models.TextField()
    location = models.TextField()
    medical_information = models.TextField()
    fatherName = models.CharField(max_length=200,blank=True)
    fatherContact = models.CharField(max_length=30,blank=True)
    motherName = models.CharField(max_length=200,blank=True)
    motherContact = models.CharField(max_length=30,blank=True)
    guardianName = models.CharField(max_length=200,blank=True)
    guardianContact = models.CharField(max_length=30,blank=True)
    classroom = models.ForeignKey(Stage, on_delete=models.CASCADE)
    termly_fees = models.ForeignKey(TermFees,on_delete=models.CASCADE)
    amount_payable = models.FloatField()
    amount_paid = models.FloatField()
    amount_owing = models.FloatField()
    date_paid = models.DateTimeField(auto_now_add=True)
    
    
    
    def _str__(self):
        return self.fullname
    class Meta:
        verbose_name_plural = "Admit Student"



class Account_Salary_Teaching(models.Model):
    teacher = models.ForeignKey(Teachers,on_delete=models.CASCADE)
    amount_paid = models.FloatField()
    date_paid = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.teacher 
    class Meta:
        verbose_name_plural = "Account Salary Teaching"


class Account_Salary_NonTeaching(models.Model):
    non_teaching = models.ForeignKey(NonTeachers,on_delete=models.CASCADE)
    amount_paid = models.FloatField()
    date_paid = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self. non_teaching
    class Meta:
        verbose_name_plural = "Account Salary NonTeaching"
 

class SuperVision(models.Model):
    teacher = models.ForeignKey(Teachers,on_delete=models.CASCADE)
    report = models.TextField()
    date = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.teacher
    class Meta:
        verbose_name_plural = "Supervision"



