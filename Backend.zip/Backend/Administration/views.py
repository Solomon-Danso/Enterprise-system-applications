from django.shortcuts import render
from .serializers import *
from .models import TermFees,Stage,Subject,MaritalStatus,Teachers,NonTeachers,AdmitTeachers,AdmitStudent,Account_Salary_Teaching,Account_Salary_NonTeaching,SuperVision
from django.http import JsonResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status




@api_view(['GET','POST'])
def term_fees(request):
    if request.method == 'GET':
        my_data = TermFees.objects.all()
        serializer = TermFeesSerializer(my_data,many=True)
        return JsonResponse(serializer.data,safe=False)
    if request.method == "POST":
        serializer = TermFeesSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=status.HTTP_201_CREATED)

@api_view(['GET','PUT','DELETE'])
def term_fees_detail(request,id):
    my_data  = TermFees.objects.get(pk=id)
    if request.method == "GET":
        serializer = TermFeesSerializer(my_data)
        return Response(serializer.data)
    elif request.method == "PUT":
        serializer = TermFeesSerializer(my_data,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
    
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)





@api_view(["GET","POST"])
def stage(request):
    if request.method == "GET":
        my_data = Stage.objects.all()
        serializer = StageSerializer(my_data,many=True)
        return Response(serializer.data)
    if request.method == "POST":
        serializer = StageSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

@api_view(["GET","PUT","DELETE"])
def stage_detail(request,id):
    mydata = Stage.objects.get(pk=id)
    if request.method == "GET":
        serializer = StageSerializer(mydata)
        return Response(serializer.data)
    elif request.method == "PUT":
        serializer = StageSerializer(mydata, data= request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
    elif request.method == "DELETE":
        mydata.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(['GET','POST'])
def superVision(request):
    if request.method == "GET":
        my_data = SuperVision.objects.all()
        serializer = SuperVisionSerializer(my_data,many=True)
        return JsonResponse(serializer.data,safe=False)
    if request.method == "POST":
        serializer = SuperVisionSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
@api_view(['GET','PUT','DELETE'])
def supervision_detail(request,id):
    my_data = SuperVision.objects.get(pk=id)
    if request.method == "GET":
        serializer = SuperVisionSerializer(my_data)
        return Response(serializer.data)
    elif request.method == "PUT":
        serializer = SuperVisionSerializer(my_data, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
            
    




def account_Salary_NonTeaching(request):
    my_data = Account_Salary_NonTeaching.objects.all()
    serializer = Account_Salary_NonTeachingSerializer(my_data,many=True)
    return JsonResponse(serializer.data,safe=False)

def account_Salary_Teaching(request):
    my_data = Account_Salary_Teaching.objects.all()
    serializer = Account_Salary_TeachingSerializer(my_data,many=True)
    return JsonResponse(serializer.data,safe=False)

def teachers(request):
    my_data = Teachers.objects.all()
    serializer = TeachersSerializer(my_data,many=True)
    return JsonResponse(serializer.data,safe=False)

def subject(request):
    my_data = Subject.objects.all()
    serializer = SubjectSerializer(my_data,many=True)
    return JsonResponse(serializer.data,safe=False)

def maritalStatus(request):
    my_data = MaritalStatus.objects.all()
    serializer = MaritalStatusSerializer(my_data,many=True)
    return JsonResponse(serializer.data,safe=False)

def nonTeachers(request):
    my_data = NonTeachers.objects.all()
    serializer = NonTeachersSerializer(my_data,many=True)
    return JsonResponse(serializer.data,safe=False)

def admitTeachers(request):
    my_data = AdmitTeachers.objects.all()
    serializer = AdmitTeachersSerializer(my_data,many=True)
    return JsonResponse(serializer.data,safe=False)

def admitStudent(request):
    my_data = AdmitStudent.objects.all()
    serializer = AdmitStudentSerializer(my_data,many=True)
    return JsonResponse(serializer.data,safe=False)

