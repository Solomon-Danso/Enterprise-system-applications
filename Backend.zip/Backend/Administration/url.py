from django.urls import path
from Administration import views

urlpatterns = [
    path('admin/stage',views.stage),
    path('admin/stage/<int:id>',views.stage_detail),
    
    path('admin/termfees',views.term_fees),
    path('admin/termfees/<int:id>',views.term_fees_detail),
    
    path('admin/supervision',views.superVision),
    path('admin/supervision/<int:id>',views.supervision_detail),
    
    path('admin/account-salary-nonteaching',views.account_Salary_NonTeaching),
    path('admin/account-salary-teaching',views.account_Salary_Teaching),
    path('admin/teachers',views.teachers),
    path('admin/subject',views.subject),
    path('admin/marital-status',views.maritalStatus),
    path('admin/nonteachers',views.nonTeachers),
    path('admin/admit-teachers',views.admitTeachers),
    path('admin/admit-student',views.admitStudent),

]