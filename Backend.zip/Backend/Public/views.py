from django.shortcuts import render
from .models import Header, Slider,EnrollMent,Event,AcademicCalender,WelcomeMessage,Join_as_Student,Student_Admission_Procedure,Join_as_StaffMember,Job_Opening,Join_as_Volunteer,Volunteer_Opening,Join_as_National_Service_Personnel,National_service_Opening,News_and_Update,GalleryPictures,GalleryVideo,GalleryAudio,School_and_address,Newsletter,SocialMedia,SchoolIcon,SchoolLinks,Portals,QuickLinks,FooterMessage
from .serializers import *
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status

@api_view(["GET","POST"])
def header(request):
    if request.method == "GET":
        my_data = Header.objects.all()
        serial = HeaderSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = HeaderSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def header_detail(request,id):
    my_data = Header.objects.get(pk=id)
    if request.method == 'GET':
        serial = HeaderSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = HeaderSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(["GET","POST"])
def slider(request):
    if request.method == "GET":
        my_data = Slider.objects.all()
        serial = SliderSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = SliderSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def slider_detail(request,id):
    my_data = Slider.objects.get(pk=id)
    if request.method == 'GET':
        serial = SliderSerializer(my_data,many=True)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = SliderSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(["GET","POST"])
def enrollMent(request):
    if request.method == "GET":
        my_data = EnrollMent.objects.all()
        serial = EnrollMentSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = EnrollMentSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def enrollMent_detail(request,id):
    my_data = EnrollMent.objects.get(pk=id)
    if request.method == 'GET':
        serial = EnrollMentSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = EnrollMentSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(["GET","POST"])
def event(request):
    if request.method == "GET":
        my_data = Event.objects.all()
        serializer = EventSerializer(my_data,many=True)
        return Response(serializer.data)
    if request.method == "POST":
        serial = EventSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def event_detail(request,id):
    my_data = Event.objects.get(pk=id)
    if request.method == 'GET':
        serial = EventSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = EventSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(["GET","POST"])
def academicCalender(request):
    if request.method == "GET":
        my_data = AcademicCalender.objects.all()
        serial = AcademicCalenderSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = AcademicCalenderSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def academicCalender_detail(request,id):
    my_data = AcademicCalender.objects.get(pk=id)
    if request.method == 'GET':
        serial = AcademicCalenderSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = AcademicCalenderSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(["GET","POST"])
def welcomeMessage(request):
    if request.method == "GET":
        my_data = WelcomeMessage.objects.all()
        serial = WelcomeMessageSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = WelcomeMessageSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def welcomeMessage_detail(request,id):
    my_data = WelcomeMessage.objects.get(pk=id)
    if request.method == 'GET':
        serial = WelcomeMessageSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = WelcomeMessageSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(["GET","POST"])
def join_as_Student(request):
    if request.method == "GET":
        my_data = Join_as_Student.objects.all()
        serial = Join_as_StudentSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = Join_as_StudentSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def join_as_Student_detail(request,id):
    my_data = Join_as_Student.objects.get(pk=id)
    if request.method == 'GET':
        serial = Join_as_StudentSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = Join_as_StudentSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(["GET","POST"])
def student_Admission_Procedure(request):
    if request.method == "GET":
        my_data = Student_Admission_Procedure.objects.all()
        serial = Student_Admission_ProcedureSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = Student_Admission_ProcedureSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def student_Admission_Procedure_detail(request,id):
    my_data = Student_Admission_Procedure.objects.get(pk=id)
    if request.method == 'GET':
        serial = Student_Admission_ProcedureSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = Student_Admission_ProcedureSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(["GET","POST"])
def join_as_StaffMember(request):
    if request.method == "GET":
        my_data = Join_as_StaffMember.objects.all()
        serial = HeaderSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = Join_as_StaffMemberSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def join_as_StaffMember_detail(request,id):
    my_data = Join_as_StaffMember.objects.get(pk=id)
    if request.method == 'GET':
        serial = Join_as_StaffMemberSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = Join_as_StaffMemberSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(["GET","POST"])
def job_Opening(request):
    if request.method == "GET":
        my_data = Job_Opening.objects.all()
        serial = Job_OpeningSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = Job_OpeningSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def job_Opening_detail(request,id):
    my_data = Job_Opening.objects.get(pk=id)
    if request.method == 'GET':
        serial = Job_OpeningSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = Job_OpeningSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(["GET","POST"])
def join_as_Volunteer(request):
    if request.method == "GET":
        my_data = Join_as_Volunteer.objects.all()
        serial = Join_as_VolunteerSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = Join_as_VolunteerSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def join_as_Volunteer_detail(request,id):
    my_data = Join_as_Volunteer.objects.get(pk=id)
    if request.method == 'GET':
        serial = Join_as_VolunteerSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = Join_as_VolunteerSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(["GET","POST"])
def footerMessage(request):
    if request.method == "GET":
        my_data = FooterMessage.objects.all()
        serial = FooterMessageSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = FooterMessageSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def footerMessage_detail(request,id):
    my_data = FooterMessage.objects.get(pk=id)
    if request.method == 'GET':
        serial = FooterMessageSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = FooterMessageSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(["GET","POST"])
def quickLinks(request):
    if request.method == "GET":
        my_data = QuickLinks.objects.all()
        serial = QuickLinksSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = QuickLinksSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def quickLinks_detail(request,id):
    my_data = QuickLinks.objects.get(pk=id)
    if request.method == 'GET':
        serial = QuickLinksSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = QuickLinksSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(["GET","POST"])
def portals(request):
    if request.method == "GET":
        my_data = Portals.objects.all()
        serial = PortalsSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = PortalsSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def portals_detail(request,id):
    my_data = Portals.objects.get(pk=id)
    if request.method == 'GET':
        serial = PortalsSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = PortalsSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(["GET","POST"])
def schoolLinks(request):
    if request.method == "GET":
        my_data = SchoolLinks.objects.all()
        serial = SchoolLinksSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = SchoolLinksSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def schoolLinks_detail(request,id):
    my_data = SchoolLinks.objects.get(pk=id)
    if request.method == 'GET':
        serial = SchoolLinksSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = SchoolLinksSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(["GET","POST"])
def volunteer_Opening(request):
    if request.method == "GET":
        my_data = Volunteer_Opening.objects.all()
        serial = Volunteer_OpeningSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = Volunteer_OpeningSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def volunteer_Opening_detail(request,id):
    my_data = Volunteer_Opening.objects.get(pk=id)
    if request.method == 'GET':
        serial = Volunteer_OpeningSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = Volunteer_OpeningSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(["GET","POST"])
def join_as_National_Service_Personnel(request):
    if request.method == "GET":
        my_data = Join_as_National_Service_Personnel.objects.all()
        serial = Join_as_National_Service_PersonnelSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = Join_as_National_Service_PersonnelSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def join_as_National_Service_Personnel_detail(request,id):
    my_data = Join_as_National_Service_Personnel.objects.get(pk=id)
    if request.method == 'GET':
        serial = Join_as_National_Service_PersonnelSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = Join_as_National_Service_PersonnelSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)




@api_view(["GET","POST"])
def national_service_Opening(request):
    if request.method == "GET":
        my_data = National_service_Opening.objects.all()
        serial = National_service_OpeningSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = HeaderSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def national_service_Opening_detail(request,id):
    my_data = National_service_Opening.objects.get(pk=id)
    if request.method == 'GET':
        serial = National_service_OpeningSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = National_service_OpeningSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)




@api_view(["GET","POST"])
def news_and_Update(request):
    if request.method == "GET":
        my_data = News_and_Update.objects.all()
        serial = News_and_UpdateSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = News_and_UpdateSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def news_and_Update_detail(request,id):
    my_data = News_and_Update.objects.get(pk=id)
    if request.method == 'GET':
        serial = News_and_UpdateSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = News_and_UpdateSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)



@api_view(["GET","POST"])
def galleryPictures(request):
    if request.method == "GET":
        my_data = GalleryPictures.objects.all()
        serial = GalleryPicturesSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = GalleryPicturesSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def galleryPictures_detail(request,id):
    my_data = GalleryPictures.objects.get(pk=id)
    if request.method == 'GET':
        serial = GalleryPicturesSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = GalleryPicturesSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(["GET","POST"])
def galleryVideo(request):
    if request.method == "GET":
        my_data = GalleryVideo.objects.all()
        serial = GalleryVideoSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = GalleryVideoSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def galleryVideo_detail(request,id):
    my_data = GalleryVideo.objects.get(pk=id)
    if request.method == 'GET':
        serial = GalleryVideoSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = GalleryVideoSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)




@api_view(["GET","POST"])
def galleryAudio(request):
    if request.method == "GET":
        my_data = GalleryAudio.objects.all()
        serial = GalleryAudioSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = GalleryAudioSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def galleryAudio_detail(request,id):
    my_data = GalleryAudio.objects.get(pk=id)
    if request.method == 'GET':
        serial = GalleryAudioSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = GalleryAudioSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(["GET","POST"])
def school_and_address(request):
    if request.method == "GET":
        my_data = School_and_address.objects.all()
        serial = School_and_addressSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = School_and_addressSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def school_and_address_detail(request,id):
    my_data = School_and_address.objects.get(pk=id)
    if request.method == 'GET':
        serial = School_and_addressSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = School_and_addressSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(["GET","POST"])
def newsletter(request):
    if request.method == "GET":
        my_data = Newsletter.objects.all()
        serial = NewsletterSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = NewsletterSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def newsletter_detail(request,id):
    my_data = Newsletter.objects.get(pk=id)
    if request.method == 'GET':
        serial = NewsletterSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = NewsletterSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)




@api_view(["GET","POST"])
def socialMedia(request):
    if request.method == "GET":
        my_data = SocialMedia.objects.all()
        serial = SocialMediaSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = SocialMediaSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def socialMedia_detail(request,id):
    my_data = SocialMedia.objects.get(pk=id)
    if request.method == 'GET':
        serial = SocialMediaSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = SocialMediaSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(["GET","POST"])
def schoolIcon(request):
    if request.method == "GET":
        my_data = SchoolIcon.objects.all()
        serial = SchoolIconSerializer(my_data,many=True)
        return Response(serial.data)
    if request.method == "POST":
        serial = SchoolIconSerializer(data = request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
@api_view(["GET","PUT","DELETE"])
def schoolIcon_detail(request,id):
    my_data = SchoolIcon.objects.get(pk=id)
    if request.method == 'GET':
        serial = SchoolIconSerializer(my_data)
        return Response(serial.data)
    elif request.method == "PUT":
        serial = SchoolIconSerializer(my_data,data=request.data)
        if serial.is_valid():
            serial.save()
            return Response(serial.data)
    elif request.method == "DELETE":
        my_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)




