from django.db import models

class Header(models.Model):
    logo = models.FileField(upload_to="public/header/")
    sign_in = models.CharField(max_length=200)
    @classmethod
    def object(cls):
        return cls._default_manager.all().first() # Since only one item

    def save(self, *args, **kwargs):
        self.pk = self.id = 1
        return super().save(*args, **kwargs)
    class Meta:
        verbose_name_plural = "Header"
    def __str__(self):
        return self.sign_in

class Slider(models.Model):
    image = models.FileField(upload_to="public/sliderImage")
    message = models.CharField(max_length=200)
    link = models.CharField(max_length=2000)
    class Meta:
        verbose_name_plural = "Slider"
    def __str__(self):
        return self.department
class EnrollMent(models.Model):
    establishment_year = models.IntegerField()
    number_of_students = models.IntegerField()
    nationalities = models.IntegerField()
    extra_curricular = models.IntegerField()
    @classmethod
    def object(cls):
        return cls._default_manager.all().first() # Since only one item

    @classmethod
    def object(cls):
        return cls._default_manager.all().first() # Since only one item

    def save(self, *args, **kwargs):
        self.pk = self.id = 1
        return super().save(*args, **kwargs)

    class Meta:
        verbose_name_plural = "Enrollment Fact"
    def __str__(self):
        return str(self.establishment_year)
class Event(models.Model):
    date = models.DateField()
    title = models.CharField(max_length=1000)
    event_category = models.CharField(max_length=500)
    details = models.TextField()
    sysdate = models.DateTimeField(auto_now_add=True)
    class Meta:
        verbose_name_plural = "Events"
        ordering = ('-sysdate',)
    def __str__(self):
        return self.title
class AcademicCalender(models.Model):
    title = models.CharField(max_length=500)
    details = models.TextField()
    class Meta:
        verbose_name_plural = "Academic Calender"
    def __str__(self):
        return self.title
class WelcomeMessage(models.Model):
    title = models.CharField(max_length=500)
    content = models.TextField()
    @classmethod
    def object(cls):
        return cls._default_manager.all().first() # Since only one item

    @classmethod
    def object(cls):
        return cls._default_manager.all().first() # Since only one item

    def save(self, *args, **kwargs):
        self.pk = self.id = 1
        return super().save(*args, **kwargs)

    class Meta:
        verbose_name_plural = "Welcome Message"
    def __str__(self):
        return self.title
class Join_as_Student(models.Model):
    image = models.FileField(upload_to="Public/JoinAs")
    home_title = models.CharField(max_length=100)
    detail_header_image = models.FileField(upload_to="Public/JoinAs")
    detail_header_text = models.CharField(max_length=200)
    detail_header_content = models.TextField(blank=True)
    detail_body_text = models.CharField(max_length=200)
    detail_body_content = models.TextField()
    @classmethod
    def object(cls):
        return cls._default_manager.all().first() # Since only one item

    def save(self, *args, **kwargs):
        self.pk = self.id = 1
        return super().save(*args, **kwargs)
    class Meta:
        verbose_name_plural = "Join as a student"
    def __str__(self):
        return self.home_title
class Student_Admission_Procedure(models.Model):
    title = models.CharField(max_length=200)
    detail = models.TextField(max_length=200)
    class Meta:
        verbose_name_plural = "Student Admission Procedure"
    def __str__(self):
        return self.title

class Join_as_StaffMember(models.Model):
    image = models.FileField(upload_to="Public/JoinAs")
    home_title = models.CharField(max_length=100)
    detail_header_image = models.FileField(upload_to="Public/JoinAs")
    detail_header_text = models.CharField(max_length=200)
    detail_header_content = models.TextField(blank=True)
    detail_body_text = models.CharField(max_length=200)
    detail_body_content = models.TextField()
    @classmethod
    def object(cls):
        return cls._default_manager.all().first() # Since only one item

    def save(self, *args, **kwargs):
        self.pk = self.id = 1
        return super().save(*args, **kwargs)
    class Meta:
        verbose_name_plural = "Join as staff member"
    def __str__(self):
        return self.home_title
class Job_Opening(models.Model):
    title = models.CharField(max_length=200)
    detail = models.TextField(max_length=200)
    class Meta:
        verbose_name_plural = "Job Opening"
    def __str__(self):
        return self.title

class Join_as_Volunteer(models.Model):
    image = models.FileField(upload_to="Public/JoinAs")
    home_title = models.CharField(max_length=100)
    detail_header_image = models.FileField(upload_to="Public/JoinAs")
    detail_header_text = models.CharField(max_length=200)
    detail_header_content = models.TextField(blank=True)
    detail_body_text = models.CharField(max_length=200)
    detail_body_content = models.TextField()
    @classmethod
    def object(cls):
        return cls._default_manager.all().first() # Since only one item

    def save(self, *args, **kwargs):
        self.pk = self.id = 1
        return super().save(*args, **kwargs)
    class Meta:
        verbose_name_plural = "Join as Volunteer"
    def __str__(self):
        return self.home_title
class Volunteer_Opening(models.Model):
    title = models.CharField(max_length=200)
    detail = models.TextField(max_length=200)
    class Meta:
        verbose_name_plural = "Volunteer Opening"
    def __str__(self):
        return self.title

class Join_as_National_Service_Personnel(models.Model):
    image = models.FileField(upload_to="Public/JoinAs")
    home_title = models.CharField(max_length=100)
    detail_header_image = models.FileField(upload_to="Public/JoinAs")
    detail_header_text = models.CharField(max_length=200)
    detail_header_content = models.TextField(blank=True)
    detail_body_text = models.CharField(max_length=200)
    detail_body_content = models.TextField()
    @classmethod
    def object(cls):
        return cls._default_manager.all().first() # Since only one item

    def save(self, *args, **kwargs):
        self.pk = self.id = 1
        return super().save(*args, **kwargs)
    class Meta:
        verbose_name_plural = "Join as National Service Personnel"
    def __str__(self):
        return self.home_title
class National_service_Opening(models.Model):
    title = models.CharField(max_length=200)
    detail = models.TextField(max_length=200)
    class Meta:
        verbose_name_plural = "National Service Opening"
    def __str__(self):
        return self.title

class News_and_Update(models.Model):
    image = models.FileField(upload_to="public/newsUpdate")
    title = models.CharField(max_length=1000)
    detail_image = models.FileField(upload_to="public/newsUpdate")
    content = models.TextField(blank=True)
    class Meta:
        verbose_name_plural = "News and Updates"
    def __str__(self):
        return self.title

class GalleryPictures(models.Model):
    title = models.CharField(max_length=1000)
    image = models.FileField("public/Gallery/Photos")
    class Meta:
        verbose_name_plural = "Picture Gallery"
    def __str__(self):
        return self.title

class GalleryVideo(models.Model):
    title = models.CharField(max_length=1000)
    video = models.FileField("public/Gallery/Video")
    class Meta:
        verbose_name_plural = "Video Gallery"
    def __str__(self):
        return self.title

class GalleryAudio(models.Model):
    title = models.CharField(max_length=1000)
    audio = models.FileField("public/Gallery/Audio")
    class Meta:
        verbose_name_plural = "Audio Gallery"
    def __str__(self):
        return self.title

class School_and_address(models.Model):
    title = models.CharField(max_length=200)
    detail = models.TextField()
    class Meta:
        verbose_name_plural = "School and Address"
    def __str__(self):
        return self.title


class Newsletter(models.Model):
    email = models.EmailField()
    class Meta:
        verbose_name_plural = "NewsLetter"
    def __str__(self):
        return self.email

class SocialMedia(models.Model):
    icon = models.FileField(upload_to="public/SocialMedia")
    link = models.CharField(max_length=400)
    class Meta:
        verbose_name_plural = "Social Media"
    def __str__(self):
        return self.link

class SchoolIcon(models.Model):
    icon = models.FileField(upload_to="public/SocialMedia")
    link = models.CharField(max_length=400)
    class Meta:
        verbose_name_plural = "School Icons"
    def __str__(self):
        return self.link

class SchoolLinks(models.Model):
    title = models.CharField(max_length=400)
    link = models.CharField(max_length=400)
    class Meta:
        verbose_name_plural = "School Links"
    def __str__(self):
        return self.title


class Portals(models.Model):
    title = models.CharField(max_length=400)
    link = models.CharField(max_length=400)
    class Meta:
        verbose_name_plural = "Portals Links"
    def __str__(self):
        return self.title

class QuickLinks(models.Model):
    title = models.CharField(max_length=400)
    link = models.CharField(max_length=400)
    class Meta:
        verbose_name_plural = "Quick Links"
    def __str__(self):
        return self.title

class FooterMessage(models.Model):
    title = models.CharField(max_length=200)
    class Meta:
        verbose_name_plural = "Footer Message"
    def __str__(self):
        return self.title




