from django.urls import path,include
from Public import views as public
urlpatterns = [

    path('public/header',public.header),
    path("public/header/<int:id>",public.header_detail),

    path('public/slider',public.slider),
    path("public/slider/<int:id>",public.slider_detail),


    path('public/enrollment',public.enrollMent),
    path("public/enrollment/<int:id>",public.enrollMent_detail),

    path('public/event',public.event),
    path("public/event/<int:id>",public.event_detail),


    path('public/academiccalender',public.academicCalender),
    path("public/academiccalender/<int:id>",public.academicCalender_detail),

    path('public/welcomemessage',public.welcomeMessage),
    path("public/welcomemessage/<int:id>",public.welcomeMessage_detail),


    path('public/join_as_Student',public.join_as_Student),
    path("public/join_as_Student/<int:id>",public.join_as_Student_detail),

    path('public/student_Admission_Procedure',public.student_Admission_Procedure),
    path("public/student_Admission_Procedure/<int:id>",public.student_Admission_Procedure_detail),


    path('public/join_as_StaffMember',public.join_as_StaffMember),
    path("public/join_as_StaffMember/<int:id>",public.join_as_StaffMember_detail),

    path('public/header',public.header),
    path("public/header/<int:id>",public.header_detail),


    path('public/job_Opening',public.job_Opening),
    path("public/job_Opening/<int:id>",public.job_Opening_detail),

    path('public/job_Opening_detail',public.job_Opening_detail),
    path("public/job_Opening_detail/<int:id>",public.job_Opening_detail),


    path('public/join_as_Volunteer',public.join_as_Volunteer),
    path("public/join_as_Volunteer/<int:id>",public.join_as_Volunteer_detail),

    path('public/footerMessage',public.footerMessage),
    path("public/footerMessage/<int:id>",public.footerMessage_detail),


    path('public/quickLinks',public.quickLinks),
    path("public/quickLinks/<int:id>",public.quickLinks_detail),

    path('public/portals',public.portals),
    path("public/portals/<int:id>",public.portals_detail),

    path('public/schoolLinks',public.schoolLinks),
    path("public/schoolLinks/<int:id>",public.schoolLinks_detail),

    path('public/volunteer_Opening',public.volunteer_Opening),
    path("public/volunteer_Opening/<int:id>",public.volunteer_Opening_detail),


    path('public/join_as_National_Service_Personnel',public.join_as_National_Service_Personnel),
    path("public/join_as_National_Service_Personnel/<int:id>",public.join_as_National_Service_Personnel_detail),

    path('public/national_service_Opening',public.national_service_Opening),
    path("public/national_service_Opening/<int:id>",public.national_service_Opening_detail),

    path('public/news_and_Update',public.news_and_Update),
    path("public/news_and_Update/<int:id>",public.news_and_Update_detail),

    path('public/galleryPictures',public.galleryPictures),
    path("public/galleryPictures/<int:id>",public.galleryPictures_detail),


    path('public/galleryVideo',public.galleryVideo),
    path("public/galleryVideo/<int:id>",public.galleryVideo_detail),

    path('public/galleryAudio',public.galleryAudio),
    path("public/galleryAudio/<int:id>",public.galleryAudio_detail),


    path('public/school_and_address',public.school_and_address),
    path("public/school_and_address/<int:id>",public.school_and_address_detail),

    path('public/newsletter',public.newsletter),
    path("public/newsletter/<int:id>",public.newsletter_detail),


    path('public/socialMedia',public.socialMedia),
    path("public/socialMedia/<int:id>",public.socialMedia_detail),

    path('public/schoolIcon',public.schoolIcon),
    path("public/schoolIcon/<int:id>",public.schoolIcon_detail),



]