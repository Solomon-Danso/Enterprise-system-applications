from rest_framework import serializers
from .models import Header, Slider,EnrollMent,Event,AcademicCalender,WelcomeMessage,Join_as_Student,Student_Admission_Procedure,Join_as_StaffMember,Job_Opening,Join_as_Volunteer,Volunteer_Opening,Join_as_National_Service_Personnel,National_service_Opening,News_and_Update,GalleryPictures,GalleryVideo,GalleryAudio,School_and_address,Newsletter,SocialMedia,SchoolIcon,SchoolLinks,Portals,QuickLinks,FooterMessage

class HeaderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Header
        fields = '__all__'

class SliderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Slider
        fields = '__all__'

class EnrollMentSerializer(serializers.ModelSerializer):
    class Meta:
        model = EnrollMent
        fields = "__all__"

class EventSerializer(serializers.ModelSerializer):
    class Meta:
        model = Event
        fields = '__all__'


class AcademicCalenderSerializer(serializers.ModelSerializer):
    class Meta:
        model = AcademicCalender
        fields = '__all__'


class WelcomeMessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = WelcomeMessage
        fields = '__all__'


class Join_as_StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Join_as_Student
        fields = '__all__'

class Student_Admission_ProcedureSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student_Admission_Procedure
        fields = '__all__'


class Join_as_StaffMemberSerializer(serializers.ModelSerializer):
    class Meta:
        model = Join_as_StaffMember
        fields = '__all__'


class Job_OpeningSerializer(serializers.ModelSerializer):
    class Meta:
        model = Job_Opening
        fields = '__all__'


class Join_as_VolunteerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Join_as_Volunteer
        fields = '__all__'

class Volunteer_OpeningSerializer(serializers.ModelSerializer):
    class Meta:
        model = Volunteer_Opening
        fields = '__all__'


class Join_as_National_Service_PersonnelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Join_as_National_Service_Personnel
        fields = '__all__'



class News_and_UpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = News_and_Update
        fields = '__all__'


class GalleryPicturesSerializer(serializers.ModelSerializer):
    class Meta:
        model = GalleryPictures
        fields = '__all__'


class National_service_OpeningSerializer(serializers.ModelSerializer):
    class Meta:
        model = National_service_Opening
        fields = '__all__'


class GalleryVideoSerializer(serializers.ModelSerializer):
    class Meta:
        model = GalleryVideo
        fields = '__all__'


class GalleryAudioSerializer(serializers.ModelSerializer):
    class Meta:
        model = GalleryAudio
        fields = '__all__'


class School_and_addressSerializer(serializers.ModelSerializer):
    class Meta:
        model = School_and_address
        fields = '__all__'


class NewsletterSerializer(serializers.ModelSerializer):
    class Meta:
        model = Newsletter
        fields = '__all__'


class SocialMediaSerializer(serializers.ModelSerializer):
    class Meta:
        model = SocialMedia
        fields = '__all__'


class SchoolIconSerializer(serializers.ModelSerializer):
    class Meta:
        model = SchoolIcon
        fields = '__all__'


class SchoolLinksSerializer(serializers.ModelSerializer):
    class Meta:
        model = SchoolLinks
        fields = '__all__'


class PortalsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Portals
        fields = '__all__'


class QuickLinksSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuickLinks
        fields = '__all__'


class FooterMessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = FooterMessage
        fields = '__all__'
